# Wikipedia 人工复核完整任务清单

更新时间：2026-10-10  
适用范围：D12 严格试点、D14 最新 400 账户主队列及匹配右删失对照。  
目标：把程序生成的 `t_f_proxy` 候选转化为经过双人独立审核、分歧裁决、可追溯且可用于 onset recovery 评估的 benchmark 标签。

## 0. 当前数据与任务规模

- 最新封禁候选主队列：400 个唯一账户、4,219 条公开 revision 事件。
- 400 个账户中：
  - 249 个：`pending_double_review`，需要双人行为复核；
  - 14 个：`pending_policy_relevance_review`，先判断是否符合研究定义；
  - 137 个：`exclude_no_public_revision_evidence`，没有公开 revision，不能强行标注 onset。
- 有公开事件的账户共 263 个；没有公开事件的账户共 137 个。
- D12 严格试点：10 个正例候选、10 个活动量匹配右删失对照、70 条事件。
- 当前优先候选：D12 的 10 个 + D14 新增的 18 个，共 28 个候选。
- D14 新增 18 个候选中：4 个长延迟、6 个非左删失、8 个左删失短延迟。
- 当前独立第二标注者复核：0%；分歧裁决：0%；正式金标准：0%。

说明：D11、D12、D13、D14 是累计扩展阶段，不能把各阶段账户数相加。全量候选以 D14 的 400 账户主队列为准。

## 1. 必须遵守的角色安排

- [ ] 指定人工标注者 A。
- [ ] 指定人工标注者 B。
- [ ] 指定第三方裁决者 C（老师或另一位熟悉任务的研究者）。
- [ ] A、B 使用相同规范，但互相看不到对方结论。
- [ ] A、B 不查看程序推荐的 `candidate_tf_proxy` 和现有三段式理由。
- [ ] 如果现有候选主要由程序规则生成，则它只能算预标注，不能代替人工标注者 A。
- [ ] 同一个人不能同时充当 A、B 和 C。

## 2. 冻结原始数据与标注规范

- [ ] 原始采集目录设为只读工作基线，不覆盖原始 CSV/JSONL。
- [ ] 固定标注协议版本，例如 `wikipedia_tf_v1.0`。
- [ ] 固定观察窗口、纳入条件、排除条件、类别和置信度定义。
- [ ] 记录每个标注文件的创建时间、协议版本和匿名标注者 ID。
- [ ] 保留原始文件哈希；每次产生新版本时另存文件，不原地覆盖。

标注规范：

`C:\Users\jercy\Desktop\paper\tf恶意检测\SafePlus-datasets-clean\docs\WIKIPEDIA_ANNOTATION_PROTOCOL.md`

字段及泄漏规范：

`C:\Users\jercy\Desktop\paper\tf恶意检测\实验数据\D12_Wikipedia_tf严格标注试点_20261005\benchmark_pilot\SCHEMA.md`

## 3. 制作双人盲审材料

- [ ] 从原始事件表生成 `reviewer_a_blinded.csv`。
- [ ] 生成独立的 `reviewer_b_blinded.csv`。
- [ ] 两份表随机打乱实体顺序。
- [ ] 保留 `entity_id`、事件顺序、revision ID、时间、diff 链接和 block-log 链接。
- [ ] 隐藏 `candidate_tf_proxy`、候选 event ID、现有置信度和三段式理由。
- [ ] 隐藏另一位标注者所有结论。
- [ ] 补充当前复核表缺少的 `category`、`left_censored`、`evidence_visible` 和 `exclusion_reason` 字段。

每位标注者必须填写：

```text
reviewer_id
entity_id
include: yes / no / uncertain
exclusion_reason
evidence_visible: yes / partial / no
category
onset_event_id
onset_time
confidence: High / Medium / Low
left_censored: 0 / 1
why_tf
why_not_before
why_not_after
notes
protocol_version
```

## 4. 第一批：完成 D12 严格试点

### 4.1 十个正例候选双人盲审

- [ ] A 按时间顺序检查 10 个实体的全部 revision diff。
- [ ] B 独立检查同一批 10 个实体。
- [ ] 每个纳入样本必须指向具体 revision ID 和时间。
- [ ] 每个纳入样本必须填写 `why_tf`、`why_not_before`、`why_not_after`。
- [ ] 最早可见事件已经恶意时，标记 `left_censored=1`，不能断言真实 onset 就是该时间。
- [ ] 纯用户名、账号安全、证据不可见或无法确定的样本不得强行纳入。

需要查看：

- 原始候选事件：`D12_Wikipedia_tf严格标注试点_20261005\raw_candidates\events_public.jsonl`
- 严格试点事件：`D12_Wikipedia_tf严格标注试点_20261005\benchmark_pilot\events.csv`
- 当前候选证据，仅在完成盲审后用于比较：`D12_Wikipedia_tf严格标注试点_20261005\benchmark_pilot\tf_evidence.csv`
- 当前复核模板：`D12_Wikipedia_tf严格标注试点_20261005\benchmark_pilot\independent_review_form.csv`
- 长延迟复核队列：`D12_Wikipedia_tf严格标注试点_20261005\long_delay_review_queue.csv`

### 4.2 十个匹配右删失对照审核

- [ ] 检查账户为注册账户且非临时账户。
- [ ] 检查完整 30 天随访。
- [ ] 检查当前未封禁，且随访窗口内没有公开block事件。
- [ ] 检查事件数量与正例匹配关系。
- [ ] 只能标记“窗口内未观察到封禁”，不能标记为永久正常用户。

需要查看：

- 对照实体：`D12_Wikipedia_tf严格标注试点_20261005\raw_controls_matched\control_entities.csv`
- 对照事件：`D12_Wikipedia_tf严格标注试点_20261005\raw_controls_matched\control_events.jsonl`
- 匹配关系：`D12_Wikipedia_tf严格标注试点_20261005\benchmark_pilot\matched_pairs.csv`

## 5. 第二批：完成 D14 的 18 个优先候选

### 5.1 审核顺序

- [ ] 先审核 4 个长延迟候选，确认是否真的存在较长的 `t_f_proxy` 到 `t_d` 间隔。
- [ ] 再审核 6 个非左删失候选，重点检查“为什么不能更早”。
- [ ] 最后审核 8 个左删失短延迟候选，保留左删失边界。

### 5.2 每个候选必须完成

- [ ] 打开并核对 revision diff。
- [ ] 打开并核对 block-log。
- [ ] 按时间顺序阅读全部可见事件，而不是只看最严重事件。
- [ ] 判断封禁原因是否与研究中的公开行为有关。
- [ ] 填写纳入、类别、onset、置信度、左删失和三段式理由。
- [ ] A、B结果独立保存，未合并前互不可见。

需要查看：

- 18 个优先候选：`D14_Wikipedia采集即标注_20261005\preannotations\preannotated_tf_candidates.csv`
- 200 个新增账户总状态：`D14_Wikipedia采集即标注_20261005\preannotations\preannotation_queue.csv`
- 新增真实事件：`D14_Wikipedia采集即标注_20261005\new_unique_annotated\new_events_public.jsonl`
- 自动验证结果：`D14_Wikipedia采集即标注_20261005\preannotations\preannotation_validation.json`

## 6. 第三批：审核规则未命中的账户，估计漏标率

- [ ] D14 新增数据中有 102 个“有公开事件但规则没有产生 onset 候选”的账户。
- [ ] 不得把这 102 个账户直接当作阴性或无 onset。
- [ ] 预先确定分层抽样方案，按事件数量、封禁类别、活跃期和回滚信号抽样。
- [ ] 至少先完成一个固定样本的双人审核，用于估计自动规则漏标率。
- [ ] 若资源允许，最终审核全部 102 个。
- [ ] 记录规则漏标数量、漏标类别和漏标原因。

需要查看：

- 人工审核/排除队列：`D14_Wikipedia采集即标注_20261005\preannotations\manual_review_or_exclusion.csv`
- 预标注总队列：`D14_Wikipedia采集即标注_20261005\preannotations\preannotation_queue.csv`

## 7. 第四批：政策相关性与无证据账户

### 7.1 14 个政策相关性账户

- [ ] 根据最新 400 账户主队列审核 14 个 `pending_policy_relevance_review`。
- [ ] 判断是否存在与公开行为相关的可核验证据。
- [ ] 纯用户名政策、账号安全或非行为型封禁应排除。
- [ ] 有可见行为证据的账户再进入双人 onset 审核。

### 7.2 137 个无公开revision账户

- [ ] 批量核验 `event_count=0` 和证据链接状态。
- [ ] 确认没有因采集错误、API中断或时间窗口错误导致的假缺失。
- [ ] 经核验仍无公开证据的账户标记为 `excluded_no_public_evidence`。
- [ ] 不得为这些账户生成 `t_f_proxy`。

主队列位置：

`D14_Wikipedia采集即标注_20261005\raw_candidates_400\annotation_queue.csv`

全部 4,219 条事件：

`D14_Wikipedia采集即标注_20261005\raw_candidates_400\events_public.jsonl`

## 8. 双人一致性统计

- [ ] 计算纳入标签原始一致率。
- [ ] 计算纳入标签 Cohen's kappa。
- [ ] 计算行为类别一致率及 macro-F1 或 Krippendorff alpha。
- [ ] 计算 onset event ID 完全一致率。
- [ ] 计算 onset 相差不超过 1 个事件的比例。
- [ ] 计算 onset 相差不超过 24 小时的比例。
- [ ] 计算 A/B onset 绝对时间差中位数。
- [ ] 分别统计 High、Medium、Low 置信度。
- [ ] 报告排除、uncertain、左删失和证据不可见数量。

建议输出：

```text
agreement_report_d12.json
agreement_report_d14.json
reviewer_disagreement_queue.csv
```

## 9. 分歧裁决

以下任一情况必须进入第三人裁决：

- [ ] A、B纳入结论不同；
- [ ] onset event ID不同；
- [ ] 行为类别不同；
- [ ] 左删失判断不同；
- [ ] 任一方置信度为Low；
- [ ] 任一方标记uncertain；
- [ ] 证据可访问性判断不同。

裁决结果只允许：

```text
accept_a
accept_b
select_new_onset
exclude
unresolved_uncertain
```

- [ ] 不得取两个时间的平均值。
- [ ] 不得默认选择更早时间。
- [ ] 不得把 `t_d` 自动当作 `t_f_proxy`。
- [ ] 每次裁决必须填写证据理由。

建议输出：

```text
adjudication_queue.csv
adjudication_results.csv
```

## 10. 固化最终 benchmark

- [ ] 生成 `final_tf_labels_v1.csv`。
- [ ] 生成 `final_tf_evidence_v1.csv`。
- [ ] 生成 `benchmark_manifest_v1.json`。
- [ ] 保存协议版本、数量、类别分布、左删失、uncertain和排除原因。
- [ ] 保存文件SHA-256。
- [ ] 检查实体在train/valid/test之间无交叉。
- [ ] 检查模型输入不含 `t_f_proxy`、审核标签、封禁理由文本或证据链接。
- [ ] 将 `t_f_proxy` 单独作为评估真值文件，不作为普通输入特征。
- [ ] 运行结构、时间顺序、引用完整性和泄漏验证。

最终标签建议字段：

```text
entity_id
final_include
final_category
final_tf_proxy
final_tf_event_id
t_detect
left_censored
final_confidence
final_status
review_source
adjudication_reason
protocol_version
```

## 11. benchmark完成后才启动的实验

- [ ] Exact marginalization 输出 onset posterior。
- [ ] Stochastic-EM/latent sampling，比较 samples=1/4/8/16/32。
- [ ] 比较 posterior MAP、mean、median onset。
- [ ] 计算 onset MAE。
- [ ] 计算 posterior NLL。
- [ ] 计算 50%/80%/95% interval coverage。
- [ ] 计算 interval width。
- [ ] 分别报告左删失/非左删失、长延迟/短延迟和行为类别结果。
- [ ] 同时报告固定 ever-alarm FPR 下的 early rate、alarm precision和lead time。

## 12. 推荐的近期执行顺序

1. [ ] 冻结规范并制作A/B盲审表。
2. [ ] 完成D12十个正例候选的双人盲审。
3. [ ] 审核D12十个匹配右删失对照。
4. [ ] 计算D12一致性并完成裁决。
5. [ ] 审核D14四个长延迟候选。
6. [ ] 审核D14六个非左删失候选。
7. [ ] 审核D14八个左删失候选。
8. [ ] 从102个规则未命中账户中按固定方案抽样审核。
9. [ ] 审核14个政策相关性账户。
10. [ ] 批量核验137个无公开证据账户。
11. [ ] 固化benchmark v1并保存一致性报告、裁决记录和文件哈希。
12. [ ] 在固定benchmark上运行exact与latent sampling正式实验。

## 13. 完成判定

只有同时满足以下条件，才能把数据称为“可用于正式 onset 评估的 benchmark”：

- [ ] 两名真人独立完成标注；
- [ ] 分歧样本已经裁决或明确保留uncertain；
- [ ] 每个精确onset都有具体revision ID和公开证据；
- [ ] 左删失样本已单独标记；
- [ ] 右删失对照完成随访与资格检查；
- [ ] 一致性指标已报告；
- [ ] 证据文件和模型输入完成泄漏隔离；
- [ ] 最终版本、协议和哈希已经冻结。

