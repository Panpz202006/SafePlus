# D12 数据字段与使用边界

## 文件角色

| 文件 | 角色 | 是否可直接作为模型输入 |
|---|---|---|
| `entities.csv` | 完整实体标签、删失状态和审计状态 | 否，包含 `t_f_proxy` |
| `events.csv` | 完整事件与证据审计表 | 否，包含候选事件类型和事后审核信息 |
| `tf_evidence.csv` | `t_f_proxy` 三段式证据链 | 否，仅用于评估和人工审核 |
| `model_input.csv` | 生存任务实体端点表 | 是，但 `detected` 是监督标签、`t_d` 是观测终点，不应当作普通行为特征 |
| `model_events.csv` | 已移除标签和事后审核信息的事件特征表 | 是 |
| `matched_pairs.csv` | 活动量匹配关系 | 用于划分、配对分析，不作为模型特征 |
| `independent_review_form.csv` | 第二位标注者复核表 | 否 |

## 时间字段

- `t_i`：固定30天观察窗口的起点。
- `t_f_proxy`：第一次有足够公开证据支持恶意行为已经发生的候选时间，仅在 benchmark/评估视图出现。
- `t_d`：对于已检测样本是公开封禁时间；对于未检测样本是30天随访截止时间。
- `detected`：`1` 表示观察到公开封禁，`0` 表示截至 `t_d` 右删失；`0` 不等于永久正常。
- `time_since_t_i_hours`：事件距观察窗口起点的小时数。
- `delta_previous_event_hours`：事件距同一实体上一事件的小时数；首事件固定为0。

## 事件级安全特征

`model_events.csv` 当前允许：

- `step_index`
- `time_since_t_i_hours`
- `delta_previous_event_hours`
- `size`
- `sizediff`
- `abs_sizediff`
- `minor`
- `new`
- `top`

下面字段只存在于审计表，禁止直接加入基线模型：

- `event_type`：包含候选 onset 身份。
- `tags`：可能包含 `mw-reverted`、`possible vandalism` 等事后审核信号。
- `comment`、`title`：当前 pilot 尚未完成安全的文本特征处理，且可能携带强人工提示。
- `raw_reference`：仅用于证据追溯。

## 划分要求

pilot 只有20个实体，不适合宣称稳定的泛化性能。如用于流水线测试，应以 `matched_pair_id` 为分组单位划分，保证一对样本进入同一折或按预先规定的配对交叉验证执行；不得把同一实体的事件拆到不同集合。

正式 Experiment 03 前必须先完成第二位标注者独立复核、分歧裁决和一致性统计，然后锁定标签版本及文件 SHA-256。
