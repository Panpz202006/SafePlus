# Wikipedia `t_f_proxy` 严格标注试点

## 本批数据解决什么问题

本目录按照“原始行为—时间标签—证据链”三层结构构建，不把平台封禁时间直接当作恶意行为发生时间。对已检测账户，`t_d` 是公开封禁日志时间；`t_f_proxy` 是当前证据下第一次足以支持恶意行为已经发生的公开 revision 时间。对照账户只表示固定窗口内没有观察到公开封禁，属于右删失，不是永久正常标签。

## 实际采集结果

- 原始封禁候选：80 个注册账户，封禁前 30 天共 1,119 条公开 revision 元数据。
- 初版右删失候选包含大量高活跃账户，与正例存在明显活动量混杂，因此没有继续用于 benchmark。
- 优化后的对照来自公开账户创建日志：账户创建后完整随访 30 天，排除临时账户、当前封禁账户和随访期内存在公开封禁事件的账户，再按正例事件数做最近邻匹配。
- 严格 pilot：20 个实体，其中 10 个带公开封禁端点的恶意行为候选、10 个右删失对照。
- 严格 pilot 事件：70 条，其中正例 34 条、对照 36 条；两组事件数中位数均为 2。
- `t_f_proxy` 候选证据行：10 条；每条都保存 `why_tf`、`why_not_before`、`why_not_after`、revision 链接和 block-log 链接。
- 通过重新选择有明确前序行为的样本和更保守的 onset，左删失正例由 9/10 降至 6/10；这些样本仍不能被描述成不可观测的真实意图时间。

## 文件结构

- `raw_candidates/`：80 个封禁候选及其公开事件元数据；自动分类只用于分流。
- `raw_controls/`：初版高活跃对照，仅为问题审计保留，不参与当前 benchmark。
- `raw_controls_matched/`：按注册队列、完整 30 天随访和事件数量匹配后的右删失对照；当前 benchmark 使用此目录。
- `tf_candidate_decisions.json`：10 个 onset 候选的逐条选择理由。
- `benchmark_pilot/entities.csv`：实体级 `t_i`、`t_f_proxy`、`t_d`、检测/删失状态和复核状态。
- `benchmark_pilot/events.csv`：可排序事件时间线与公开 revision 链接。
- `benchmark_pilot/tf_evidence.csv`：三段式证据链。
- `benchmark_pilot/model_input.csv`：模型输入视图，不包含 `t_f_proxy`，用于避免泄漏。
- `benchmark_pilot/model_events.csv`：事件级安全训练视图；移除了 `event_type`、审核 tags、评论、标题和证据链接，只保留时间、顺序、大小变化和基础编辑标志。
- `benchmark_pilot/matched_pairs.csv`：10 组按事件数量匹配的正例—右删失对照关系。
- `benchmark_pilot/independent_review_form.csv`：第二位标注者独立复核表。
- `benchmark_pilot/manifest.json`：来源、语义和数量清单。
- `benchmark_pilot/validation_report.json`：结构、时间顺序、引用完整性和泄漏检查结果。
- `benchmark_pilot/SCHEMA.md`：逐文件字段角色、允许的模型特征和禁止泄漏字段说明。
- `benchmark_pilot/data_layer_annotations.csv`：逐实体注明哪些字段来自真实平台记录、哪些由实验构造，以及允许和禁止得出的结论。
- `benchmark_pilot/data_layer_annotation_summary.json`：真实层与构造层批注统计。
- `long_delay_review_queue.csv`：自动筛出的长延迟候选复核队列；仅用于后续人工审核，不属于当前正式标签。

## 训练视图与证据视图隔离

`events.csv` 是审计与标注文件，包含候选 onset 的 `event_type`、公开审核 tags、评论和证据链接，不能直接送入模型。`model_events.csv` 才是当前基线允许使用的事件级输入，包含 `step_index`、距观察起点时间、距上一事件时间、页面大小变化和基础编辑标志。验证脚本会拒绝将 `t_f_proxy`、候选事件类型、审核 tags 或证据链接带入模型视图。

## 当前时间跨度限制

10 个正例从候选 `t_f_proxy` 到公开封禁的间隔中位数约为 0.165 小时（约 9.9 分钟），最短约 0.014 小时，最长约 5.20 小时。因此本 pilot 适合检查短延迟的 `t_f` sampling 流程，但暂时不足以单独支撑长期提前检测结论。

当前原始候选中另筛出 3 个间隔超过 24 小时的样本，放入 `long_delay_review_queue.csv`。它们涉及 disruptive editing、sockpuppetry 或 checkuser 场景，与主 pilot 的 vandalism 语义并不完全一致，必须先人工确认行为定义，不能直接并入主结果。

## 当前能做与不能做

现在可以把这批数据交给老师确认标注口径，并让第二位标注者独立查看 revision diff 与封禁日志。当前不能把 10 个候选 `t_f_proxy` 当成已经完成双人一致性审核的最终 benchmark，也不能把 10 个右删失账户写成真实正常用户。

第二位标注者填写完成后，需要计算纳入结论一致率、onset 完全一致率、24 小时内一致率和时间差中位数；有分歧的样本进入裁决。只有裁决后的标签才能用于 Experiment 03 的正式 sampling 评估。

## 复现命令

```powershell
python scripts/build_wikipedia_tf_pilot.py `
  --blocked-dir "实验数据/D12_Wikipedia_tf严格标注试点_20261005/raw_candidates" `
  --control-dir "实验数据/D12_Wikipedia_tf严格标注试点_20261005/raw_controls_matched" `
  --decisions "实验数据/D12_Wikipedia_tf严格标注试点_20261005/tf_candidate_decisions.json" `
  --output "实验数据/D12_Wikipedia_tf严格标注试点_20261005/benchmark_pilot"

python scripts/validate_wikipedia_tf_pilot.py `
  "实验数据/D12_Wikipedia_tf严格标注试点_20261005/benchmark_pilot"
```

本次验证结果为 `pass`：20 个实体、70 条活动量较平衡的事件、10 条证据链、10 个匹配对，以及实体级和事件级两个训练视图均通过时间约束、引用完整性、实体哈希和标签泄漏检查。
