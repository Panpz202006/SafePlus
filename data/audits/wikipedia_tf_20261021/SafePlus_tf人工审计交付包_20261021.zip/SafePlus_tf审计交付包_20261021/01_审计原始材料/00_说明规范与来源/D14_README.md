# D14 Wikipedia 采集即标注

## 真实数据采集

- 通过英文 Wikipedia 官方 MediaWiki Action API 获取400个注册账户的公开封禁日志。
- 收集封禁前30天共4,219条公开 revision 元数据。
- 以D13的200个账户为基线去重，得到200个新增账户、2,165条新增真实事件。
- 126个新增账户具有公开 revision；74个没有公开事件证据，明确排除 `t_f_proxy` 标注。
- 120个账户满足基本复核条件；6个账户需要先做政策相关性审核。

## 同步预标注结果

采集完成后，对新增账户立即执行证据规则筛选，并生成可追溯的第一轮候选标注：

- 18个账户产生候选 `t_f_proxy`；
- 15个为 Provisional-High，3个为 Provisional-Medium；
- 15个 vandalism，3个 spam/promotion；
- 4个为超过24小时的长延迟候选；
- 6个候选前面存在未触发证据规则的公开事件，属于非左删失优先复核样本；
- 8个为短延迟且首条可见事件即候选 onset 的左删失样本；
- 102个虽有事件但没有触发严格规则，保留给人工逐条审核，不强行生成 onset；
- 74个无公开事件证据，排除；
- 6个需政策/资格审核。

每个候选都保存：

- `candidate_tf_proxy`
- `candidate_tf_event_id`
- `candidate_delay_hours`
- `why_tf`
- `why_not_before`
- `why_not_after`
- revision diff 链接
- block-log 链接
- 左删失标记
- 置信度和复核优先级

## 标签真实性边界

revision、事件时间和 block-log 是真实公开记录。候选 `t_f_proxy` 和三段式理由来自确定性的证据筛选规则，是研究构造的第一轮预标注，不是 Wikipedia 提供的原生标签，也不是已经完成的人工双人标注。

所有18个候选都明确标为 `candidate_pending_independent_human_review`。人工审核可以接受、修改或排除候选；在独立复核和裁决前不能作为最终 benchmark 标签。

## 文件

- `raw_candidates_400/`：400账户和4,219条事件的完整原始采集。
- `new_unique_annotated/new_entities_annotated.csv`：200个新增账户的来源和资格批注。
- `new_unique_annotated/new_events_public.jsonl`：2,165条去重后新增真实事件。
- `preannotations/preannotation_queue.csv`：全部200账户的采集后标注状态。
- `preannotations/preannotated_tf_candidates.csv`：18个带完整证据链的候选 `t_f_proxy`。
- `preannotations/manual_review_or_exclusion.csv`：其余人工审核或排除样本。
- `preannotations/preannotation_summary.json`：预标注统计。
- `preannotations/preannotation_validation.json`：候选事件归属、时间顺序、三段式理由和标签终态检查。

## 建议审核顺序

1. 先审核4个长延迟候选，判断它们能否补足D12短延迟问题。
2. 再审核6个非左删失候选，重点检查“为什么不能更早”。
3. 最后审核8个左删失短延迟候选。
4. 对规则没有触发的102个账户另做人工语义审核，不应为了数量强行标注。
