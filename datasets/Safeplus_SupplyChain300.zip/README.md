# Safeplus_SupplyChain300

基于用户提供的 SafePlus GitHub 分支 ZIP 整理的供应链生命周期研究数据集。

**内容**：300 条软件包级序列（200 恶意、100 已筛查正常对照）；42,669 行版本时间线；692 行证据；R1/R2 各 300 条审计。

**使用**：先打开 `Safeplus_SupplyChain300.pdf` 阅读字段、TF/TD 和质量限制，再使用同名 Excel 阅读样本总表。全量时间线在 `data/provisional_timeline.csv`。

**特别说明**：这是源文件注明的 B 级、provisional / pending_manual_final_review 研究交付。恶意 TD 是公开安全公告代理时间，不是 npm/PyPI 官方移除时间；正常对照已筛查但不代表绝对安全；未声称人工 Gold 终审。

`delivery_validation.json` 为针对上传快照的独立检查；并未重新在线抓取注册表/安全公告。

源仓库：https://github.com/Panpz202006/SafePlus ，分支 `data/supplychain-lifecycle-300-v1`。
